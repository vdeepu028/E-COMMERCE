import  pymysql
class connection:
    def connection(self):
        conn=pymysql.connect('192.168.64.2','root','','deepu')
        return conn