


function addcategorypage() {

    if($('#form3').valid()) {
        var category = document.getElementById('category').value;
        var description = document.getElementById('description').value;


        var xml = new XMLHttpRequest();
        xml.onreadystatechange = function () {
            if (this.readyState == 4 && this.status == 200) {
                var ar = JSON.parse(this.response);
                document.getElementById('sp1').innerHTML = ar["msg"];
            }

        };
        xml.open('GET', 'addcategoryaction?category=' + category + "&description=" + description, true);
        xml.send();
    }

}

