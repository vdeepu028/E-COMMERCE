"""ajax URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from mycontrollers import *

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',indexpage),
    path('showpage',showpage),
    path('oddeve',oddeve),
    path('addemp',addemp),
    path('addempaction',addempaction),
    path('viewemprender',viewemprender),
    path('viewemp',viewemp),
    path('removeemp',removeemp),
    path('updateemp',updateemp),
    path('saveemp',saveemp),
    path('adminlogin',adminlogin),
    path('adminloginaction',adminloginaction),
    path('addcategorypage',addcategorypage),
    path('adminhomepage',adminhomepage),
    path('adminlogout',adminlogut),
    path('addcategoryaction',addcategoryaction),
    path('viewcategorypage',viewcategorypage),
    path('removecategory',removecategory),
    path('updatecategory',updatecategory),
    path('savecategory',savecategory),
    path('usersignup',usersignup),
    path('usersignupaction',usersignupaction),
    path('addproductpage',addproductpagerender),
    path('addproductaction',addproductaction),
    path('viewproductpage',viewproductpage),
    path('viewproductaction',viewproductaction),
    path('removeproduct',removeproduct),
    path('showallproductpage',showallproductpage),
    path('showallproductaction',showallproductaction),
    path('addtocartaction',addtocartaction),
    path('mycart',mycart),
    path('mycartaction',mycartaction),
    path('userlogin',userlogin),
    path('userloginaction',userloginaction),
    path('proceedtopay',proceedtopay),
    path('userhomepage',userhomepage),
    path('billinginfo',billinginfo),
    path('userlogout',userlogout),
    path('checkoutaction',checkoutaction),
    path('thankspage',thankspage),
    path('pendingorderpage',pendingorderpage),
    path('pendingordersaction',pendingordersaction),
    path('approve_reject_action',approve_reject_action),
    path('myorders',myorders),
    path('myordersaction',myordersaction),
    path('showproductbycategory',showproductbycategory),
    path('viewproductbycategory',viewproductbycategory),
    path('searchproductbyname',searchproductbyname)
]
