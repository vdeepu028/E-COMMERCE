from django.http import *
from django.shortcuts import *
from connectionfile import *
from django.views.decorators.csrf import *
from django.core.files.storage import FileSystemStorage

from datetime import *
import http.client
import smtplib




def indexpage(request):
    conn = connection.connection('')
    cr = conn.cursor()
    x = []
    qry = "select * from categorytable"
    cr.execute(qry)
    res = cr.fetchall()
    for p in res:
        d = {}
        d["categoryname"] = p[0]
        x.append(d)
    return render(request,'index.html',{'mydata':x})



def showpage(request):
    return  render(request,'ajax1.html')

def oddeve(request):
    a=int(request.GET["num"])
    d={}
    if a%2==0 :
        d['ans']='even'
    else:
        d['ans']='odd'
    return JsonResponse(d,safe=False)
#---------------------------------------------
def addemp(request):
    return  render(request,'addemp.html')
def addempaction(request):
    fullname=request.GET['fullname']
    emailid=request.GET['emailid']
    password=request.GET['password']
    admintype=request.GET['admintype']
    conn=connection.connection('')
    qry="insert into admin values('"+fullname+"','"+emailid+"','"+password+"','"+admintype+"') "
    cr=conn.cursor()
    res=cr.execute(qry)
    conn.commit()
    conn.close()
    d={}
    if res:
        d["msg"]="ADDED SUCCESSFULLY"
    else:
        d["msg"]="ERROR "
    return JsonResponse(d,safe=False)
def viewemprender(request):
    return render(request,'viewemp.html')
def viewemp(request):
    conn = connection.connection('')
    qry="select * from admin"
    cr=conn.cursor()
    cr.execute(qry)
    result=cr.fetchall()
    x=[]
    for p in result:
        d={}
        d["fullname"]=p[0]
        d["emailid"]=p[1]
        d["password"]=p[2]
        d["admintype"]=p[3]
        s=str(p[1])
        d["removeurl"]='removeemp?q='+s
        d["updateurl"]='updateemp?q='+s

        x.append(d)
    return render(request,"viewemp.html",{"mydata":x})
def removeemp(request):
    conn = connection.connection('')
    qry="delete from admin where emailid='"+request.GET['q']+"'"
    cr=conn.cursor()
    cr.execute(qry)
    conn.commit()
    conn.close()
    return HttpResponseRedirect('viewemp')
def updateemp(request):
    conn = connection.connection('')
    qry="select * from admin where emailid='"+request.GET['q']+"'"
    cr=conn.cursor()
    cr.execute(qry)
    result=cr.fetchone()
    d={}
    d["fullname"]=result[0]
    d["emailid"]=result[1]
    d["password"]=result[2]
    d["admintype"]=result[3]
    return render(request,'updateemp.html',d)
def saveemp(request):
    conn = connection.connection('')
    qry="update admin set fullname='"+request.GET["fullname"]+"',password='"+request.GET["password"]+"',admintype='"+request.GET["admintype"]+"'where emailid='"+request.GET["emailid"]+"'"
    cr=conn.cursor()
    cr.execute(qry)
    conn.commit()
    return HttpResponseRedirect('viewemp')
def adminlogin(request):
    return render(request,'adminlogin.html')
@csrf_exempt
def adminloginaction(request):
    emailid = request.POST['emailid']
    password = request.POST['password']
    conn = connection.connection('')
    cr = conn.cursor()
    flag = False
    s = "select * from admin"
    cr.execute(s)
    result = cr.fetchall()
    for p in result:
        if p[1] == emailid and p[2] == password:
            request.session['ADMIN'] = p[0]
            flag = True
            break
    d = {}
    if flag == False:
        d['msg'] = "INVALID LOGIN"
    else:
        d['msg'] = "LOGIN SUCCESS"
    return JsonResponse(d, safe=False)
def adminhomepage(request):
    d={}
    d['name']=request.session['ADMIN']
    return render(request,'adminhomepage.html',d)
def adminlogut(request):
    del request.session['ADMIN']
    return HttpResponseRedirect('adminlogin')

#____________________________________
def addcategorypage(request):
    return  render(request,'addcategorypage.html')
def addcategoryaction(request):
    category=request.GET['category']
    description=request.GET['description']
    conn=connection.connection('')
    qry="insert into categorytable values('"+category+"','"+description+"') "
    cr=conn.cursor()
    res=cr.execute(qry)
    conn.commit()
    conn.close()
    d={}
    if res:
        d["msg"]="ADDED SUCCESSFULLY"
    else:
        d["msg"]="ERROR "
    return JsonResponse(d,safe=False)
def viewcategoryrender(request):
    return render(request,'viewcategory.html')
def viewcategorypage(request):
    conn = connection.connection('')
    qry="select * from categorytable"
    cr=conn.cursor()
    cr.execute(qry)
    result=cr.fetchall()
    x=[]
    for p in result:
        d={}
        d["category"]=p[0]
        d["description"]=p[1]


        s=str(p[0])
        d["removeurl"]='removecategory?q='+s
        d["updateurl"]='updatecategory?q='+s

        x.append(d)
    return render(request,"viewcategory.html",{"mydata":x})
def removecategory(request):
    conn = connection.connection('')
    qry="delete from categorytable where categoryname='"+request.GET['q']+"'"
    cr=conn.cursor()
    cr.execute(qry)
    conn.commit()
    conn.close()
    return HttpResponseRedirect('viewcategorypage')
def updatecategory(request):
    conn = connection.connection('')
    qry="select * from categorytable where categoryname='"+request.GET['q']+"'"
    cr=conn.cursor()
    cr.execute(qry)
    result=cr.fetchone()
    d={}
    d["categoryname"]=result[0]
    d["description"]=result[1]


    return render(request,'updatecategory.html',d)
def savecategory(request):
    conn = connection.connection('')
    qry="update categorytable set categoryname='"+request.GET["categoryname"]+"',description='"+request.GET["description"]+"'where categoryname='"+request.GET["categoryname"]+"'"
    cr=conn.cursor()
    cr.execute(qry)
    conn.commit()
    return HttpResponseRedirect('viewcategorypage')
def usersignup(request):
    return render(request,'usersignup.html')
def usersignupaction(request):
    conn=connection.connection('')
    cr=conn.cursor()
    email=request.GET['email']
    fullname = request.GET['fullname']
    mobileno = request.GET['mobileno']
    address = request.GET['address']
    city = request.GET['city']
    password = request.GET['password']
    qry="insert into usersignup values ('"+email+"','"+fullname+"','"+mobileno+"','"+address+"','"+city+"','"+password+"')"
    res=cr.execute(qry)
    conn.commit()
    conn.close()
    d = {}
    if res:
        d["msg"] = "ADDED SUCCESSFULLY"
    else:
        d["msg"] = "ERROR "
    return JsonResponse(d, safe=False)
def addproductpagerender(request):
    conn=connection.connection('')
    cr=conn.cursor()
    x=[]
    qry="select * from categorytable"
    cr.execute(qry)
    res=cr.fetchall()
    for p in res:
        d={}
        d["categoryname"]=p[0]
        x.append(d)
    return render(request,'addproductpage.html',{'mydata':x})
@csrf_exempt
def addproductaction(request):
    conn=connection.connection('')
    cr=conn.cursor()
    categoryname=request.POST['categoryname']
    pname=request.POST['pname']
    price=request.POST['price']
    mrp=request.POST['mrp']
    description=request.POST['description']
    photo=request.FILES['photo']
    fs=FileSystemStorage()
    filename=fs.save(photo.name,photo)
    location=fs.url(filename)
    s="insert into producttable values (null,'"+pname+"','"+description+"','"+price+"','"+mrp+"','"+filename+"','"+categoryname+"')"
    cr.execute(s)
    conn.commit()
    conn.close()
    d={}
    d['msg']="DATA SAVED"
    return JsonResponse(d,safe=False)
def viewproductpage(request):
    return render(request,'viewproductpage.html')
def viewproductaction(request):
    conn = connection.connection('')
    qry="select * from producttable"
    cr=conn.cursor()
    cr.execute(qry)
    result=cr.fetchall()
    x=[]
    for p in result:
        d={}
        d["pid"]=p[0]
        d["pname"]=p[1]
        d["description"]=p[2]
        d["price"]=p[3]
        d["mrp"] = p[4]
        d["photo"] = p[5]
        d["categoryname"] = p[6]


        x.append(d)
    return JsonResponse(x,safe=False)
def removeproduct(request):
    conn = connection.connection('')
    pid=request.GET['pid']

    qry="delete from producttable where pid='"+str(pid)+"'"
    cr=conn.cursor()
    cr.execute(qry)
    conn.commit()
    conn.close()
    return HttpResponseRedirect('viewproductpage')
def showallproductpage(request):
    return render(request,'showallproductpage.html')
def showallproductaction(request):
    conn = connection.connection('')
    qry = "select * from producttable"
    cr = conn.cursor()
    cr.execute(qry)
    result = cr.fetchall()
    x = []
    for p in result:
        d = {}
        d["pid"] = p[0]
        d["pname"] = p[1]
        d["description"] = p[2]
        d["price"] = p[3]
        d["mrp"] = p[4]
        d["photo"] = p[5]
        d["categoryname"] = p[6]

        x.append(d)
    return JsonResponse(x, safe=False)
def addtocartaction(request):
    CARTLIST=[]
    if request.session.has_key('MYCART'):
        CARTLIST=request.session['MYCART']
    pid=request.GET['pid']
    qty=request.GET['qty']
    conn = connection.connection('')
    qry = "select * from producttable where pid='"+str(pid)+"'"
    cr = conn.cursor()
    cr.execute(qry)
    result = cr.fetchall()
    x = []
    for p in result:
        d = {}
        d["pid"] = p[0]
        d["pname"] = p[1]
        d["description"] = p[2]
        d["price"] = p[3]
        d["mrp"] = p[4]
        d["photo"] = p[5]
        d["categoryname"] = p[6]
        d['qty']=qty
        d['total']=float(p[3])*float(qty)

        CARTLIST.append(d)

    request.session['MYCART']=CARTLIST
    return JsonResponse(x, safe=False)
def mycart(request):
    conn = connection.connection('')
    cr = conn.cursor()
    x = []
    qry = "select * from categorytable"
    cr.execute(qry)
    res = cr.fetchall()
    for p in res:
        d = {}
        d["categoryname"] = p[0]
        x.append(d)

    return render(request,'mycart.html',{'mydata':x})
def mycartaction(request):
    if request.session.has_key('MYCART'):
        k=request.session['MYCART']
    else:
        k=[]
    return JsonResponse(k,safe=False)
def userlogin(request):
    return render(request,'userlogin.html')
@csrf_exempt
def userloginaction(request):
    emailid=request.POST['emailid']
    password=request.POST['password']
    conn=connection.connection('')
    cr=conn.cursor()
    flag=False
    s="select * from usersignup"
    cr.execute(s)
    result=cr.fetchall()
    for p in result:
        if p[0]==emailid and p[5]==password:
            request.session['USEREMAIL']=emailid
            flag=True
            break
    d={}
    if flag==False:
        d['msg']="INVALID LOGIN"
    else:
        d['msg']="LOGIN SUCCESS"
    return JsonResponse(d,safe=False)
def proceedtopay(request):
    if request.session.has_key('USEREMAIL'):
        k="/billinginfo"
    else:
        k="/userlogin"
    return HttpResponseRedirect(k)
def userhomepage(request):
    conn = connection.connection('')
    cr = conn.cursor()
    x = []
    qry = "select * from categorytable"
    cr.execute(qry)
    res = cr.fetchall()
    for p in res:
        d = {}
        d["categoryname"] = p[0]
        x.append(d)
    return render(request,'userhomepage.html',{'mydata':x})
def billinginfo(request):
    conn=connection.connection('')
    cr=conn.cursor()
    flag=False
    s="select * from usersignup where email='"+request.session['USEREMAIL']+"'"
    cr.execute(s)
    result=cr.fetchall()
    d={}
    for p in result:
        d['fullname']=p[1]
        d['mobileno']=p[2]
        d['address'] =p[3]
        d['city'] =p[4]
        netamount=0
        for i in range(0,len(request.session['MYCART'])):
            ar=request.session['MYCART']
            netamount=netamount+ar[i]['total']
        d['netamount']=netamount
        return render(request,'billinginfo.html',d)
def userlogout(request):
    del request.session['USEREMAIL']
    if request.session.has_key('MYCART'):
        del request.session['MYCART']



    return HttpResponseRedirect('/')

@csrf_exempt
def checkoutaction(request):
    email=request.POST['email']
    fullname=request.POST['fullname']
    netamount=request.POST['netamount']
    mobileno=request.POST['mobileno']
    address=request.POST['address']
    city=request.POST['city']
    paymentmode=request.POST['paymentmode']
    conn=connection.connection('')
    dt=datetime.now().date()
    status="Pending"
    s="insert into ordertable values (null,'"+email+"','"+fullname+"','"+mobileno+"','"+address+"','"+city+"','"+str(netamount)+"','"+str(dt)+"','"+status+"','"+paymentmode+"')"
    cr=conn.cursor()
    res=cr.execute(s)
    conn.commit()
    orderid=cr.lastrowid
    for i in range(0,len(request.session['MYCART'])):
        ar=request.session['MYCART']
        s1="insert into orderdetail values (null ,'"+str(orderid)+"','"+str(ar[i]['pid'])+"','"+ar[i]['pname']+"','"+str(ar[i]['price'])+"','"+str(ar[i]['qty'])+"','"+str(ar[i]['total'])+"')"
        cr1=conn.cursor()
        res1=cr1.execute(s1)
        conn.commit()
    conn.close()
    msg = "Your Order has been placed for Rs." + str(
        netamount) + " .Your order will be delivered after order approval. Thank You"
    msg = msg.replace(" ", "%20")
    conn1 = http.client.HTTPConnection("server1.vmm.education")
    conn1.request('GET',
                  "/VMMCloudMessaging/AWS_SMS_Sender?username=ExamSystem&password=S4J5LT3C&message=" + msg + "&phone_numbers=" + mobileno)
    response = conn1.getresponse()
    print(response.read())
    sender = 'tania.vmmteachers23@gmail.com'
    receiver = 'vdeepu028@gmail.com'
    password = 'Teachers@123'
    try:
        smtpserver = smtplib.SMTP("smtp.gmail.com", 587)
        smtpserver.ehlo()
        smtpserver.starttls()
        smtpserver.ehlo
        smtpserver.login(sender, password)
        body = "\nYour Order has been placed for Rs." + str(
        netamount) + " .Your order will be delivered after order approval. Thank You\n\n"
        subject = "Subject:Django Shopping "
        msg = subject + body
    # msg='Subject:Demo <h1>This is a test e-mail message.</h1>'
        smtpserver.sendmail(sender, receiver, msg)
        print('Sent')
        smtpserver.close()
    except smtplib.SMTPException:

        print("Not Sent")

    d={}

    d['msg']="Data Saved"
    return JsonResponse(d,safe=False)
def thankspage(request):
    return render(request,'thankspage.html')

def pendingorderpage(request):
    return render(request,'pendinorderpage.html')
def pendingordersaction(request):
    conn = connection.connection('')
    qry = "select * from ordertable where status='Pending'order by id DESC "
    cr = conn.cursor()
    cr.execute(qry)
    result = cr.fetchall()
    x = []
    for p in result:
        d = {}
        d["id"] = p[0]
        d["email"] = p[1]
        d["fullname"] = p[2]
        d["mobileno"] = p[3]
        d["address"] = p[4]
        d["city"] = p[5]
        d["netamount"] = p[6]
        d["dateoforder"] = p[7]
        d["paymentmode"]=p[9]

        x.append(d)
    return JsonResponse(x, safe=False)
def approve_reject_action(request):
    orderid=request.GET['orderid']
    status=request.GET['status']
    
    conn=connection.connection('')
    cr=conn.cursor()
    s="update ordertable set status='"+status+"' where id='"+str(orderid)+"'"
    cr.execute(s)
    conn.commit()
    conn.close()
    d={}
    d["msg"]="DATA UPDATED"
    return JsonResponse(d,safe=False)
def myorders(request):
    return render(request,'myorders.html')
def myordersaction(request):
    email=request.GET['email']
    conn = connection.connection('')
    qry = "select * from ordertable where customeremail='"+email+"'order by id DESC "
    cr = conn.cursor()
    cr.execute(qry)
    result = cr.fetchall()
    x = []
    for p in result:
        d = {}
        d["id"] = p[0]
        d["email"] = p[1]
        d["fullname"] = p[2]
        d["mobileno"] = p[3]
        d["address"] = p[4]
        d["city"] = p[5]
        d["netamount"] = p[6]
        d["dateoforder"] = p[7]
        d["status"] = p[8]
        d["paymentmode"] = p[9]

        x.append(d)
    return JsonResponse(x, safe=False)
def showproductbycategory(request):
    categoryname=request.GET['categoryname']
    d={}
    d['categoryname']=categoryname
    return render(request,'showproductbycategory.html',d)
def viewproductbycategory(request):
    categoryname=request.GET['categoryname']
    conn = connection.connection('')
    qry = "select * from producttable where categoryname='"+categoryname+"'"
    cr = conn.cursor()
    cr.execute(qry)
    result = cr.fetchall()
    x = []
    for p in result:
        d = {}
        d["pid"] = p[0]
        d["pname"] = p[1]
        d["description"] = p[2]
        d["price"] = p[3]
        d["mrp"] = p[4]
        d["photo"] = p[5]
        d["categoryname"] = p[6]

        x.append(d)
    return JsonResponse(x, safe=False)
def searchproductbyname(request):
    name=request.GET['name']
    conn = connection.connection('')
    qry = "select * from producttable where pname LIKE'%"+name+"%' or categoryname LIKE '%"+name+"%'"
    cr = conn.cursor()
    cr.execute(qry)
    result = cr.fetchall()
    x = []
    for p in result:
        d = {}
        d["pid"] = p[0]
        d["pname"] = p[1]
        d["description"] = p[2]
        d["price"] = p[3]
        d["mrp"] = p[4]
        d["photo"] = p[5]
        d["categoryname"] = p[6]

        x.append(d)
    return JsonResponse(x, safe=False)












